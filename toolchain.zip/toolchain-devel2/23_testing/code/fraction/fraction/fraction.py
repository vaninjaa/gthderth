class Fraction:
   def __init__(self, numerator, denominator):
       self.numerator = numerator
       self.denominator = denominator
