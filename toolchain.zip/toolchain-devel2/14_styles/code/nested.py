def foo(a, b, c):
    if a > 5:
        if b > 10:
            if c != 6: 
                return a + b + c
    return None
