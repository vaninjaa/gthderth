def foo(a, b, c):
    if a <= 5:
        return None
    if b <= 10:
        return None
    if c != 6: 
        return None
    return a + b + c
