import sys
sys.path.append("/path/to/my_package")
import my_module
my_module.MyClass()
