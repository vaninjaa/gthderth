#include <iostream>

int main() {
    std::cout << "Hello World!";
    return 0;
}

float foo(int a) {
    a = 0;
    return 42. / a;
}
