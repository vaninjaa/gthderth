def generate_arithmetic_series(n):
    return list(range(n))
    
def generate_geometric(b, n):
    return list([b**i for i in range(n)])
    

